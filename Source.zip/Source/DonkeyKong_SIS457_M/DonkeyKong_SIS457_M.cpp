// Copyright Epic Games, Inc. All Rights Reserved.

#include "DonkeyKong_SIS457_M.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, DonkeyKong_SIS457_M, "DonkeyKong_SIS457_M" );
 